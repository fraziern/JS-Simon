var intervalID = 0,
  steps = [1, 2, 2, 3],
  currentStep = 0,
  dutyCycle = .5, // ratio of on time to total cycleLength
  cycleLength = 1000, // ms length of on+off
  sounds = [],
  soundURLs = [
    "https://s3.amazonaws.com/freecodecamp/simonSound1.mp3",
    "https://s3.amazonaws.com/freecodecamp/simonSound2.mp3",
    "https://s3.amazonaws.com/freecodecamp/simonSound3.mp3",
    "https://s3.amazonaws.com/freecodecamp/simonSound4.mp3"
  ];

(function setupSounds() {
  for (var i = 0; i < 4; i++) {
    sounds.push(new Audio(soundURLs[i]));
  }
})();

function nextStep() {
  if (currentStep >= steps.length) {
    currentStep = 0;
    window.clearTimeout(intervalID);
    return;
  }
  $("#btn" + steps[currentStep]).addClass("highlight");
  sounds[steps[currentStep] - 1].play();
  currentStep++;
  window.setTimeout(function() {
    $(".sbutton").removeClass("highlight");
  }, cycleLength * dutyCycle);
}

$("#test-btn").click(function() {
  intervalID = window.setInterval(nextStep, cycleLength);
});